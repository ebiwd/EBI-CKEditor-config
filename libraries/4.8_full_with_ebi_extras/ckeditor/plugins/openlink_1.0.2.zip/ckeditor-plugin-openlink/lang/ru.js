CKEDITOR.plugins.setLang( 'openlink', 'ru', {
	menu: 'Открыть ссылку'
} );
