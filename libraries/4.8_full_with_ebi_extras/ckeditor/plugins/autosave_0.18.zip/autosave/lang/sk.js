﻿/*
Copyright (c) 2003-2012, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.html or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang('autosave', 'sk', {
    dateFormat: 'LLL',
    autoSaveMessage: 'Automaticky uložené',
    loadSavedContent: 'Bola nájdená automaticky uložená verzia z "{0}". Chcete porovnať obsah a vybrať verziu, ktorú chcete použiť?',
    title: 'Porovnanie automaticky uloženého obsahu s obsahom nahraným z webu',
    loadedContent: 'Nahraný obsah z webu',
    localStorageFull: 'Browser localStorage is full, clear your storage or Increase database size',
    autoSavedContent: 'Automaticky uložený obsah z: \'',
  ok: 'Použiť automaticky uložený obsah',
  no: 'Použiť obsah z webu',
  diffType: 'Zvoliť typ náhľadu:',
  sideBySide: 'Vedľa seba',
  inline: 'Pod sebou'
});
