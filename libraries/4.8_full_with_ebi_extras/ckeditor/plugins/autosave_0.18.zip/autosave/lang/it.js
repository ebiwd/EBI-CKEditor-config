/*
Copyright (c) 2003-2012, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.html or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang('autosave', 'it', {
    dateFormat: 'LLL',
    autoSaveMessage: 'Salvataggio automatico',
    loadSavedContent: 'C\'� una versione salvata automaticamente di questi contenuti da "{0}": desideri confrontare le due versioni per decidere quale utilizzare?',
    title: 'Confronta i contenuti salvati automaticamente con quelli caricati dal sito web',
    loadedContent: 'Contenuti caricati',
    autoSavedContent: 'Contenuti salvati automaticamente da: \'',
	ok: 'Si, carica i contenuti salvati automaticamente',
	no: 'No',
	diffType: 'Scegli il tipo di visualizzazione:',
	sideBySide: 'Vista affiancata',
	inline: 'Vista in linea'
});