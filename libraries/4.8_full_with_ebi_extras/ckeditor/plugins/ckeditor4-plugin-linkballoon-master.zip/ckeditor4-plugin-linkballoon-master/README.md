# linkballoon

A simple plugin integrating Balloon Toolbar with the link feature.

![linkballoon plugin demo](assets/demo.png)