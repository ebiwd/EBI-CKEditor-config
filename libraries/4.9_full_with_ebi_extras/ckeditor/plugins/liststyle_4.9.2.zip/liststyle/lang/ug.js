/*
Copyright (c) 2003-2018, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
*/
CKEDITOR.plugins.setLang( 'liststyle', 'ug', {
	armenian: 'قەدىمكى ئەرمىنىيە تەرتىپ نومۇرى شەكلى',
	bulletedTitle: 'تۈر بەلگە تىزىم خاسلىقى',
	circle: 'بوش چەمبەر',
	decimal: 'سان (1, 2, 3 قاتارلىق)',
	decimalLeadingZero: 'نۆلدىن باشلانغان سان بەلگە (01, 02, 03 قاتارلىق)',
	disc: 'تولدۇرۇلغان چەمبەر',
	georgian: 'قەدىمكى جورجىيە تەرتىپ نومۇرى شەكلى (an, ban, gan قاتارلىق)',
	lowerAlpha: 'ئىنگلىزچە كىچىك ھەرپ (a, b, c, d, e قاتارلىق)',
	lowerGreek: 'گرېكچە كىچىك ھەرپ (alpha, beta, gamma قاتارلىق)',
	lowerRoman: 'كىچىك ھەرپلىك رىم رەقىمى (i, ii, iii, iv, v قاتارلىق)',
	none: 'بەلگە يوق',
	notset: '‹تەڭشەلمىگەن›',
	numberedTitle: 'تەرتىپ نومۇر تىزىم خاسلىقى',
	square: 'تولدۇرۇلغان تۆت چاسا',
	start: 'باشلىنىش نومۇرى',
	type: 'بەلگە تىپى',
	upperAlpha: 'ئىنگلىزچە چوڭ ھەرپ (A, B, C, D, E قاتارلىق)',
	upperRoman: 'چوڭ ھەرپلىك رىم رەقىمى (I, II, III, IV, V قاتارلىق)',
	validateStartNumber: 'تىزىم باشلىنىش تەرتىپ نومۇرى چوقۇم پۈتۈن سان پىچىمىدا بولۇشى لازىم'
} );
