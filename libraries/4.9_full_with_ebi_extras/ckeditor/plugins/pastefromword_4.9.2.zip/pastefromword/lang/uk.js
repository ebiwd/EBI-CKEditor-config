/*
Copyright (c) 2003-2018, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
*/
CKEDITOR.plugins.setLang( 'pastefromword', 'uk', {
	confirmCleanup: 'Текст, що Ви намагаєтесь вставити, схожий на скопійований з Word. Бажаєте очистити його форматування перед вставлянням?',
	error: 'Неможливо очистити форматування через внутрішню помилку.',
	title: 'Вставити з Word',
	toolbar: 'Вставити з Word'
} );
