/*
Copyright (c) 2003-2018, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
*/
CKEDITOR.plugins.setLang( 'pastefromword', 'es', {
	confirmCleanup: 'El texto que desea parece provenir de Word.\r\n¿Desea depurarlo antes de pegarlo?',
	error: 'No ha sido posible limpiar los datos debido a un error interno',
	title: 'Pegar desde Word',
	toolbar: 'Pegar desde Word'
} );
