/*
Copyright (c) 2003-2018, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
*/
CKEDITOR.plugins.setLang( 'pastefromword', 'cs', {
	confirmCleanup: 'Jak je vidět, vkládaný text je kopírován z Wordu. Chcete jej před vložením vyčistit?',
	error: 'Z důvodu vnitřní chyby nebylo možné provést vyčištění vkládaného textu.',
	title: 'Vložit z Wordu',
	toolbar: 'Vložit z Wordu'
} );
