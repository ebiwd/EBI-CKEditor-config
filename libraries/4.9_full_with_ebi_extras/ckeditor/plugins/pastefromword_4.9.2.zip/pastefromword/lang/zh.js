/*
Copyright (c) 2003-2018, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
*/
CKEDITOR.plugins.setLang( 'pastefromword', 'zh', {
	confirmCleanup: '您想貼上的文字似乎是自 Word 複製而來，請問您是否要先清除 Word 的格式後再行貼上？',
	error: '由於發生內部錯誤，無法清除清除 Word 的格式。',
	title: '自 Word 貼上',
	toolbar: '自 Word 貼上'
} );
