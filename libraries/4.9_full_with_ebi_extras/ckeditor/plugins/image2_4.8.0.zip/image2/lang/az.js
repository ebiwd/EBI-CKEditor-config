/*
Copyright (c) 2003-2017, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
*/
CKEDITOR.plugins.setLang( 'image2', 'az', {
	alt: 'Alternativ mətn',
	btnUpload: 'Serverə göndər',
	captioned: 'Altyazı olan şəkil',
	captionPlaceholder: 'Altyazı',
	infoTab: 'Şəkil haqqında məlumat',
	lockRatio: 'Ölçülərin nisbəti saxla',
	menu: 'Şəklin seçimləri',
	pathName: 'Şəkil',
	pathNameCaption: 'Altyazı',
	resetSize: 'Ölçüləri qaytar',
	resizer: 'Ölçülər dəyişmək üçün tıklayın və aparın',
	title: 'Şəklin seçimləri',
	uploadTab: 'Serverə yüklə',
	urlMissing: 'Şəklin ünvanı yanlışdır.',
	altMissing: 'Alternativ mətn tapılmayıb'
} );
